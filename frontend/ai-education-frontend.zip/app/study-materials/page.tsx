"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"

interface StudyMaterial {
  notes?: string
  story?: string
  summary?: string
  mcqs?: string[]
  shortQuestions?: string[]
  imageUrl?: string
}

export default function StudyMaterialsPage() {
  const [topic, setTopic] = useState("")
  const [material, setMaterial] = useState<StudyMaterial | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!topic.trim()) return

    setIsLoading(true)
    setError("")
    setMaterial(null)

    try {
      const response = await fetch("/api/generate-material", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic }),
      })

      if (!response.ok) throw new Error("Failed to generate material")

      const data = await response.json()
      setMaterial(data)
    } catch (err) {
      setError("Failed to generate study material. Please try again.")
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border sticky top-0 bg-card z-10">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Study Materials</h1>
            <p className="text-sm text-muted-foreground">Generate comprehensive study materials</p>
          </div>
          <Link href="/">
            <Button variant="outline">Chat</Button>
          </Link>
        </div>
      </header>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Search Form */}
        <Card className="p-6 mb-8">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="topic" className="block text-sm font-medium text-foreground mb-2">
                Enter a topic or subject
              </label>
              <div className="flex gap-2">
                <Input
                  id="topic"
                  type="text"
                  placeholder="e.g., Photosynthesis, World War II, Calculus..."
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  disabled={isLoading}
                  className="flex-1"
                />
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? "Generating..." : "Generate"}
                </Button>
              </div>
            </div>
          </form>
        </Card>

        {/* Error Message */}
        {error && (
          <Card className="p-4 mb-6 bg-destructive/10 border-destructive/50">
            <p className="text-destructive">{error}</p>
          </Card>
        )}

        {/* Loading State */}
        {isLoading && (
          <Card className="p-8 text-center">
            <div className="flex justify-center mb-4">
              <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            </div>
            <p className="text-muted-foreground">Generating study materials for "{topic}"...</p>
          </Card>
        )}

        {/* Study Materials Display */}
        {material && !isLoading && (
          <div className="space-y-6">
            {/* Image */}
            {material.imageUrl && (
              <Card className="overflow-hidden">
                <img
                  src={material.imageUrl || "/placeholder.svg"}
                  alt={topic}
                  className="w-full h-auto max-h-96 object-cover"
                />
              </Card>
            )}

            {/* Study Notes */}
            {material.notes && (
              <Card className="p-6">
                <h2 className="text-xl font-bold text-foreground mb-4">📝 Study Notes</h2>
                <div className="prose prose-sm dark:prose-invert max-w-none">
                  <p className="text-foreground whitespace-pre-wrap">{material.notes}</p>
                </div>
              </Card>
            )}

            {/* Story */}
            {material.story && (
              <Card className="p-6">
                <h2 className="text-xl font-bold text-foreground mb-4">📖 Story</h2>
                <p className="text-foreground whitespace-pre-wrap">{material.story}</p>
              </Card>
            )}

            {/* Summary */}
            {material.summary && (
              <Card className="p-6">
                <h2 className="text-xl font-bold text-foreground mb-4">✍️ Summary</h2>
                <p className="text-foreground whitespace-pre-wrap">{material.summary}</p>
              </Card>
            )}

            {/* MCQs */}
            {material.mcqs && material.mcqs.length > 0 && (
              <Card className="p-6">
                <h2 className="text-xl font-bold text-foreground mb-4">❓ Multiple Choice Questions</h2>
                <div className="space-y-4">
                  {material.mcqs.map((mcq, index) => (
                    <div key={index} className="p-4 bg-muted rounded-lg">
                      <p className="text-foreground font-medium">
                        {index + 1}. {mcq}
                      </p>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* Short Questions */}
            {material.shortQuestions && material.shortQuestions.length > 0 && (
              <Card className="p-6">
                <h2 className="text-xl font-bold text-foreground mb-4">📌 Short Answer Questions</h2>
                <div className="space-y-4">
                  {material.shortQuestions.map((question, index) => (
                    <div key={index} className="p-4 bg-muted rounded-lg">
                      <p className="text-foreground font-medium">
                        {index + 1}. {question}
                      </p>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </div>
        )}

        {/* Empty State */}
        {!material && !isLoading && !error && (
          <Card className="p-8 text-center">
            <h3 className="text-lg font-semibold text-foreground mb-2">No materials generated yet</h3>
            <p className="text-muted-foreground">
              Enter a topic above to generate comprehensive study materials including notes, summaries, and questions.
            </p>
          </Card>
        )}
      </div>
    </div>
  )
}
